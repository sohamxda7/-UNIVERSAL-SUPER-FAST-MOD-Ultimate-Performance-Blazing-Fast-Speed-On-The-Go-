Android-Universal-Fly-On-Mod
=============================

Fly-On is a package of scripts and tweaks aimed to provide a smoother Android experience.
This Mod works for all Android devices with init.d support,running from Android GB 2.3 to KK 4.4
If any developers want to add this to his Rom,feel free to do in conditions to give proper credits.
