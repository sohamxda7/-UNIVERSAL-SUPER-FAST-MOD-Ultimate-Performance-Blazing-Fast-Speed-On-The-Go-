#!/bin/bash

zip -r ultimate-performance-blazing-speed-v0.3.zip . -x ".*" -x "*/.*"
