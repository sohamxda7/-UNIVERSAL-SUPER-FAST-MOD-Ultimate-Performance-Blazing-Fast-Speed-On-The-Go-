#!/system/bin/sh

cp /tmp/busybox /system/xbin/busybox
chmod a+x /system/xbin/busybox
