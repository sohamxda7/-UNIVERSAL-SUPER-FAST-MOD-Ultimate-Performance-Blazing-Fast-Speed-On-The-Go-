#!/bin/bash

zip -r renameMe.zip . -x ".*" -x "*/.*"
